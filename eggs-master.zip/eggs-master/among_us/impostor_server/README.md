# Among Us - Impostor Server
### From their [Github](https://github.com/AeonLucid/Impostor)

Impostor is one of the first Among Us private servers, written in C#.
The latest version supported is 2020.9.22, both desktop and mobile.
There are no special features at this moment, the goal is aiming to be as close as possible to the real server, for now. In a later stage, making modifications to game logic by modifying GameData packets can be looked at.

### Install notes

You MUST use Port 22023, else you can't connect

### Server Ports
Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Game    | 22023   |
