# Now abandoned. Please use NukkitX by Cloudburst.
[NukkitX](https://github.com/CloudburstMC/Nukkit)
# Nukkit

[Nukkit GitHub](https://github.com/Nukkit/Nukkit)  

Nukkit is a Nuclear-Powered Server Software For Minecraft: Pocket Edition  

