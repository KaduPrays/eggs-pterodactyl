## Technic Eggs

[Technic](/minecraft/java/technic/)   
* [Attack of the B-Team](/minecraft/java/technic/attack-of-the-bteam/)
* [Blightfall](/minecraft/java/technic/blightfall/)
* [Hexxit](/minecraft/java/technic/hexxit/)  
* [Tekkit](/minecraft/java/technic/Tekkit/)
* [Tekkit Classic](/minecraft/java/technic/tekkit-classic/)
* [Tekkit Legends](/minecraft/java/technic/tekkit-legends/)
* [The 1.7.10 Pack](/minecraft/java/technic/the-1-7-10-pack/)