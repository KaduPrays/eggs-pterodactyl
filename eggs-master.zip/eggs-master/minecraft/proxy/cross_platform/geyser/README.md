# Geyser

A bridge/proxy allowing you to connect to Minecraft: Java Edition servers with Minecraft: Bedrock edition.

### Eggs
GeyserMC maintains their own eggs on their github: [GeyserMC pterodactyl eggs](https://github.com/GeyserMC/pterodactyl-stuff)
