# Mineraft Cross Platform Proxies

### GeyserMC
[GeyserMC](https://github.com/GeyserMC/)

A bridge/proxy allowing you to connect to Minecraft: Java Edition servers with Minecraft: Bedrock edition.


#### Waterdog
[Waterdog](https://github.com/yesdog/Waterdog)

Waterdog provides native support for the Minecraft Bedrock protocols along with the existing java protocols. It is capable of using the ProtocolSupport PE encapsulation protocol over TCP, or it can use the native RakNet Bedrock protocol for traditional downstream Bedrock servers such as Nukkit, Pocketmine, Bedrock Alpha Server, MiNET, and others.

