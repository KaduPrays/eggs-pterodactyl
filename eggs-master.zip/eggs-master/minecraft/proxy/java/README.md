# Minecraft Java Proxies

#### Waterfall
[Waterfall](https://papermc.io/downloads#Waterfall)
Paper fork of the BungeeCord software, with improved Forge support and more features.

#### Travertine
[Travertine](https://papermc.io/downloads#Travertine)
Waterfall, with additional support for Minecraft 1.7.10. 

#### Velocity
[Velocity](https://velocitypowered.com/)
Velocity is a Minecraft server proxy with unparalleled server support, scalability, and flexibility. 

#### Typhoonlimbo
[TyphoonLimbo](https://github.com/TyphoonMC/TyphoonLimbo)
Lightweight Minecraft limbo server  
