# Starbound
Their desctiption:  
In Starbound, you create your own story - there’s no wrong way to play! You may choose to save the universe from the forces that destroyed your home, uncovering greater galactic mysteries in the process, or you may wish to forego a heroic journey entirely in favor of colonizing uncharted planets.

### Server Ports
Starbound requires a single port to be oepened

game ports (default 21025 )

| Port    | default |
|---------|---------|
| Game    |  21025  |