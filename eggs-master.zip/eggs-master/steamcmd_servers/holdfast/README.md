# What is Holdfast: Nations At War ?
Fight on multiple fronts in Holdfast: Nations At War - A competitive multiplayer first and third person shooter set during the great Napoleonic Era. Charge into battle with over 150 players per server!

>  [Holdfast: NaW](https://store.steampowered.com/app/589290/Holdfast_Nations_At_War/)

<img src="https://steamcdn-a.akamaihd.net/steam/apps/589290/capsule_616x353.jpg?t=1600279941" alt="logo" width="300"/></img>

# How to import an egg in [Pterodactyl](https://pterodactyl.io/)

1. Download [egg-holdfast-na-w.json](https://github.com/ankit2951/pterodactyl-holdfast/blob/main/egg-holdfast-na-w.json).
> It's easiest to right click the raw button and save as.
2. In your panel go to the Nests section in the admin part of the panel
3. Click the green Import Egg button
4. Browse to the json file you saved earlier
5. Select what nest you want to put the egg in.
> If you want a new nest you need to create it before importing the egg.
6. Restart the daemon on your node before creating a server using the new egg(s).

# You must restart your daemon after importing an egg
