# ARMA

ARMA is a series of first-person tactical military shooters, originally released for Microsoft Windows. It features large elements of realism and simulation; a blend of large-scale military conflict spread across large areas alongside the more close quartered battles.

## Arma 3
* [Arma 3](arma3)
* [Arma 3 64 Bit](arma3_x64)
* [Arma 3 Headless Client](arma3_headless_client)