# Red M

### From the [RedM](https://redm.gg/) Site
RedM, for Red Dead Redemption 2 on PC. Launching now, based on the CitizenFX framework and Cfx.re technology.

### Install notes
- Only installs latest version versions are not selectable.

### Server Ports
Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Game    | 30120   |
| ServerListing  | 30110   |
| cfx join links  | 30130   |