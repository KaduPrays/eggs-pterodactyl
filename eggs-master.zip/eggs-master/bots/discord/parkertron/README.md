# parkertron
### Their [Github](https://github.com/parkervcp/parkertron)
Purely a chatbot. Not even a smart one. 

Runs the Pterodactyl `@support bot`

### Server Ports
There are no ports required for parkertron