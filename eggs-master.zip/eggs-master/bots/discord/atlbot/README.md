# ATLBot
### Their [Github](https://github.com/ATLauncher/discord-bot)
This is the code for our Discord bot which runs on the official ATLauncher Discord server

### Server Ports
There are no ports required for the atl bot