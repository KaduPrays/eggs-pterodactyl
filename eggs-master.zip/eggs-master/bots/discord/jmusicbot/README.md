# JMusicBot
### Their [Github](https://github.com/jagrosh/MusicBot)
A Discord music bot that's easy to set up and run yourself! 

### Config

Edit the startup variables before starting the bot, otherwise it will fail to start

### Server Ports
There are no ports required for JMusicBot