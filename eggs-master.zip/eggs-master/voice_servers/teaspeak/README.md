# TeaSpeak
### From their [Website](https://teaspeak.de/)
Because a license fee is not my cup of tea!  

### Server Ports
Ports required to run the server in a table format.

| Port    | default |
|---------|---------|
| Voice   | 9987    |
| Query   | 10101   |
| File    | 30303   |