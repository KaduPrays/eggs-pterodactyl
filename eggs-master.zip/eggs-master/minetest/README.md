# Minetest

An open source voxel game engine. Play one of our many games, mod a game to your liking, make your own game, or play on a multiplayer server.
